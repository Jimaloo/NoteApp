package com.jim.notesapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.jim.notesapp.R
import com.jim.notesapp.adapter.NoteAdapter.NoteAdapterViewHolder
import com.jim.notesapp.model.Note

class NoteAdapter() : RecyclerView.Adapter<NoteAdapterViewHolder>(), View.OnClickListener {
    private var allNotes: List<Note> = ArrayList<Note>()
    val itemClickListener:ItemClickListener? = null
    var currentItem:Note? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteAdapterViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_note, parent, false)
        return NoteAdapterViewHolder(view)
    }

    override fun onBindViewHolder(holder: NoteAdapterViewHolder, position: Int) {
        val currentNote = allNotes.get(position)
        holder.title.text = currentNote.title
        holder.description.text = currentNote.description

        currentItem = allNotes.get(position)
        holder.deleteButton.setOnClickListener(this)
    }

    override fun getItemCount(): Int {
        return allNotes.size
    }

    override fun onClick(v: View?) {
        if (v != null) {
            this.itemClickListener?.onItemClick(v, currentItem?.Id!!)
        }
    }

    fun setNotes(notes: List<Note>) {
        this.allNotes = allNotes
        notifyDataSetChanged()
    }

    class NoteAdapterViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title = itemView.findViewById<TextView>(R.id.title)
        val description = itemView.findViewById<TextView>(R.id.description)
        val deleteButton = itemView.findViewById<ImageView>(R.id.deleteBtn)
    }

    interface ItemClickListener{
        fun onItemClick(v:View,position:Int)
    }
}